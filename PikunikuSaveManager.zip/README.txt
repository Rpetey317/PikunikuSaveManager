------How to use------

1.) Make sure your game is closed
2.) Select a savestate (the names are pretty self-explanatory)
3.) Select the platform you want to makke the changes in
4.) If you selected steam, click the "get" button, it should open a file explorer tab in "C:\Program Files (x86)\Steam\userdata\",
there's a folder with a long string of numbers as name, copy that number in the text field on the save manager
5.) Click "Set selected save"
6.) If you select "continue" the next time you open the game, it should have the save you set.

------Notes------

The "Export current save button" copies your current savefile (from the platform you have selected) to the saves folder.
Make sure to rename it before exporting another save because it will overwrite it otherwise.

Any save you drop on the "Pikuniku Saves" folder will pop up in the editor, and the steam and epic saves are compatible.

Do not rename or move any folder because it might break something.

This is literally the first thing I ever programmed so don't expect it to be perfect. If you find any bugs,
feel free to message me on discord (Rpetey317#9409) either by dm or on the Pikuniku Speedrunning discord.
